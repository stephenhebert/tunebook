var version = '5.10.3';

module.exports = version;
