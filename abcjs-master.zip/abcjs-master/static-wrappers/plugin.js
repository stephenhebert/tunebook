require('./license');
var abcjs = {
	plugin: require('../src/plugin/abc_plugin')
};

window.ABCJS = abcjs;
