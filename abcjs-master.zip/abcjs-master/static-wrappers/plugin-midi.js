require('./license');
var abcjs = {
	plugin: require('../src/plugin/abc_plugin_midi')
};

window.ABCJS = abcjs;
