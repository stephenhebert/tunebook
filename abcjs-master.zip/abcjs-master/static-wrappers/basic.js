require('./license');
window.ABCJS = require('../index.js');
