require('./license');
window.ABCJS = require('../midi.js');
