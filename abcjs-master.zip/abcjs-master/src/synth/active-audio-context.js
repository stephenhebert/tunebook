function activeAudioContext() {
	return window.abcjsAudioContext;
}

module.exports = activeAudioContext;
