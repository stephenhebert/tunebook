var soundsCache = {
};

module.exports = soundsCache;
