# Other Resources

[abcjs Home page](https://abcjs.net) (Overview of what this library does)

[Configurator](https://configurator.abcjs.net) (Experiment with all configuration options)

[API Documentation](api.md) (All the details about using abcjs)

[Special Notes](special-notes.md) (Notes from previous versions)

[Info for abcjs contributors](contributing.md) (Info about how abcjs is built and managed)

[Support of the ABC standard](abc-notation.md) (How abcjs varies from the ABC standard)

[Release Notes](RELEASE.md)

License: [The MIT License (MIT)](http://opensource.org/licenses/MIT)

