![abcjs](https://cdn.rawgit.com/paulrosen/abcjs/master/docs/abcjs_comp_extended_08.svg)

# Javascript library for rendering standard music notation in a browser.

This library makes it easy to incorporate **sheet music** into your **websites**. You can also turn visible **ABC** text into sheet music on websites that you don't own using a greasemonkey script, or change your own website that contains ABC text with no other changes than the addition of one javascript file. You can also generate **MIDI files** or play them directly in your browser.

Full documentation is here: [abcjs documentation](https://paulrosen.github.io/abcjs/)

## Supported by BrowserStack
If you aren't using the same browser and machine that I use, you can thank [BrowserStack](https://browserstack.com/) for their support of this open-source project.

![BrowserStack](https://cdn.rawgit.com/paulrosen/abcjs/master/docs/.vuepress/public/img/browserstack-logo-600x315.png)
